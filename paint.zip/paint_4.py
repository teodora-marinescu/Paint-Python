
from tkinter import *
import turtle
from turtle import TurtleScreen, RawTurtle, Shape
from functools import partial
from PIL import Image

#help(RawTurtle)
menu = Tk()
menu.title('Paint')


# fynction for making shapes

pen_color = 'black'
global cc #crayon color
cc='black'
global fc #fill color
fc='black'
global mode #chose cc or fc
mode = 1
global size #curent size
size=5
global xp #x pos when starting line
xp=[]
global yp #y pos when starting line
yp=[]
global la #las action tipe : draw or shape
la=['n']
with open ('name.txt','r') as f :
    name=f.read()

# turtle actions
def draw(x, y):
    turtle.ondrag(None)
    turtle.down()
    turtle.goto(x, y)
    turtle.up()
    screen.update()
    turtle.ondrag(draw)
def move(x, y):
    global xp
    global yp
    global la
    xp.append(turtle.xcor())
    yp.append(turtle.ycor())
    la.append('d') 
    screen.onscreenclick(None)
    turtle.goto(x, y)
    screen.onclick(move)
    screen.update()
def main():
    turtle.shape("circle")
    polygon = turtle.get_shapepoly()
    fixed_color_turtle = Shape("compound")
    fixed_color_turtle.addcomponent(polygon, "", "")
    screen.register_shape('fixed', fixed_color_turtle)
    turtle.shape("fixed")
    turtle.penup()
    turtle.pensize(5)
    turtle.turtlesize(2000,2000)
    turtle.ondrag(draw)
    screen.onscreenclick(move)
    screen.update()

def checkblack ():
    if cc=='black' or cc=='gray30' or cc=='saddlebrown' or cc=='mediumblue' : bpen.configure(fg='white')
    else : bpen.configure(fg='black')
    if fc=='black' or fc=='gray30' or fc=='saddlebrown' or fc=='mediumblue' : bfill.configure(fg='white')
    else : bfill.configure(fg='black')

def setcolor (color) :
    global cc
    global fc
    if mode==1 :
        cc = color
        turtle.pencolor(color)
        bpen.configure(bg=cc)
    if mode==2 :
        fc = color
        turtle.fillcolor(color)
        bfill.configure(bg=fc)
    checkblack()
   
frame=Frame(menu, bd=1, bg='#d1c7c7')
frame.grid(row=1, column=6, rowspan=26 )
canvas=Canvas(frame,width=1000, height=700)
canvas.grid(column=6,row=1, rowspan=26)
#canvas spacers
Label(menu).grid(row=19, column=0)
Label(menu).grid(row=20, column=0)
Label(menu).grid(row=21, column=0)
Label(menu).grid(row=22, column=0)
Label(menu).grid(row=23, column=0)
Label(menu).grid(row=24, column=0)
Label(menu).grid(row=25, column=0)
Label(menu).grid(row=26, column=0)
Label(menu).grid(row=26, column=0)
Label(menu).grid(row=27, column=0)
# more spacers
Label(menu).grid(column=6, row=0, sticky=EW)
Label(menu, width=10).grid(column=1, row=0)
Label(menu, width=10).grid(column=3, row=0)
c=Label(menu, width=5)
c.grid(column=7, row=27)
Label(menu, width=5).grid(column=5, row=0)
Label(menu, width=5).grid(column=2, row=0)

# color buttons
Label(menu, text='colors', width=10).grid(column=1, row=1, columnspan=2, sticky=NE)

bred = Button(
    menu,
    bg='red',
    width=4,
    command=partial(setcolor,'red')
).grid(column=1, row=2, sticky=NE)

bblack = Button(
    menu,
    bg='tomato',
    width=4,
    command=partial(setcolor,'tomato')
).grid(column=2, row=2, sticky=NW)

borng = Button(
    menu,
    bg='darkorange',
    width=4,
    command=partial(setcolor,'darkorange')
).grid(column=1, row=3, sticky=NE)

bblack = Button(
    menu,
    bg='tan1',
    width=4,
    command=partial(setcolor,'tan1')
).grid(column=2, row=3, sticky=NW)

byellow = Button(
    menu,
    bg='gold1',
    width=4,
    command=partial(setcolor,'gold1')
).grid(column=1, row=4, sticky=NE)

bblack = Button(
    menu,
    bg='yellow',
    width=4,
    command=partial(setcolor,'yellow')
).grid(column=2, row=4, sticky=NW)

bgreen = Button(
    menu,
    bg='forestgreen',
    width=4,
    command=partial(setcolor,'forestgreen')
).grid(column=1, row=5, sticky=NE)

bblack = Button(
    menu,
    bg='olivedrab1',
    width=4,
    command=partial(setcolor,'olivedrab1')
).grid(column=2, row=5, sticky=NW)

bblue = Button(
    menu,
    bg='mediumblue',
    width=4,
    command=partial(setcolor,'mediumblue')
).grid(column=1, row=6, sticky=NE)

bsteel = Button(
    menu,
    bg='steelblue1',
    width=4,
    command=partial(setcolor,'steelblue')
).grid(column=2, row=6, sticky=NW)

bpurp = Button(
    menu,
    bg='darkorchid',
    width=4,
    command=partial(setcolor,'darkorchid')
).grid(column=1, row=7, sticky=NE)

bviolet = Button(
    menu,
    bg='orchid3',
    width=4,
    command=partial(setcolor,'orchid3')
).grid(column=2, row=7, sticky=NW)

bpink = Button(
    menu,
    bg='deeppink',
    width=4,
    command=partial(setcolor,'deeppink')
).grid(column=1, row=8, sticky=NE)

bpink2 = Button(
    menu,
    bg='hotpink',
    width=4,
    command=partial(setcolor,'hotpink')
).grid(column=2, row=8, sticky=NW)

bbrown = Button(
    menu,
    bg='saddlebrown',
    width=4,
    command=partial(setcolor,'saddlebrown')
).grid(column=1, row=9, sticky=NE)

btan = Button(
    menu,
    bg='tan3',
    width=4,
    command=partial(setcolor,'tan3')
).grid(column=2, row=9, sticky=NW)

bblack = Button(
    menu,
    bg='black',
    width=4,
    command=partial(setcolor,'black')
).grid(column=1, row=10, sticky=NE)

bgray = Button(
    menu,
    bg='gray',
    width=4,
    command=partial(setcolor,'gray')
).grid(column=2, row=10, sticky=NW)

bgray2 = Button(
    menu,
    bg='gray30',
    width=4,
    command=partial(setcolor,'gray30')
).grid(column=1, row=11, sticky=NE)

bwhite = Button(
    menu,
    bg='white',
    width=4,
    command=partial(setcolor,'white')
).grid(column=2, row=11, sticky=NW)

def erase () :
    turtle.pencolor('white')
beraser = Button(
    menu,
    text='eraser',
    bg='white',
    width=10,
    command=erase
).grid(column=1, row=12, columnspan=2, sticky=NE)

Label(menu).grid(row=13,column=1)
Label(menu).grid(row=14,column=1)

frpen=Frame(menu, bg='khaki', bd=4)
frpen.grid(column=1, row=15, columnspan=2, sticky=NE)
def pencolor () :
    global mode
    mode = 1
    frpen.config(bg='khaki')
    frfill.config(bg='#F0F0F0')
bpen = Button(
    frpen,
    text='pen color',
    bg=cc,
    fg='white',
    width=10,
    command=pencolor
)
bpen.grid(column=1, row=15, columnspan=2)

frfill=Frame(menu, bg='#F0F0F0', bd=4)
frfill.grid(column=1, row=16, columnspan=2, sticky=NE)
def filcolor () :
    global mode
    mode = 2
    frfill.config(bg='khaki')
    frpen.config(bg='#F0F0F0')
bfill = Button(
    frfill,
    text='fill color',
    bg=cc,
    fg='white',
    width=10,
    command=filcolor
)
bfill.grid(column=1, row=16, columnspan=2, sticky=NE)

# brush size buttons
Label(menu, text='brush size',width=10).grid(column=3, row=1, columnspan=2, sticky=E)

def size1():
    turtle.pensize(2)
    global size
    size=2
b1 = Button(
    menu,
    text='thin',
    width=10,
    command=size1
).grid(column=3, row=2, columnspan=2, sticky=NE)

def size2():
    turtle.pensize(5)
    global size
    size=5
b2 = Button(
    menu,
    text='small',
    width=10,
    command=size2
).grid(column=3, row=3, columnspan=2, sticky=NE)

def size3():
    turtle.pensize(8)
    global size
    size=8
b3 = Button(
    menu,
    text='medium',
    width=10,
    command=size3
).grid(column=3, row=4, columnspan=2, sticky=NE)

def size4():
    turtle.pensize(12)
    global size
    size=12
b4 = Button(
    menu,
    text='big',
    width=10,
    command=size4
).grid(column=3, row=5, columnspan=2, sticky=NE)

# shape buttons
Label(menu, text='stamps').grid(column=4, row=7)

bdraw = Button(
    menu,
    text='pen',
    width=10,
    command=main
).grid(column=4, row=8)

def triangle(x, y):
    global la
    la.append('s')
    turtle.turtlesize(1,1)
    screen.onclick(None)
    turtle.ondrag(None)
    turtle.goto(x-size*8.5, y-size*6)
    turtle.pendown()
    turtle.begin_fill()
    for i in range(3):
        turtle.forward(size*18)
        turtle.left(360 / 3)
    turtle.end_fill()
    turtle.penup()
    postriangle()
def postriangle():
    screen.onclick(triangle)
btriangle = Button(
    menu,
    text='triangle',
    width=10,
    command=postriangle
).grid(column=4, row=9)

def square(x, y):
    global la
    la.append('s')
    turtle.turtlesize(1,1)
    screen.onclick(None)
    turtle.ondrag(None)
    turtle.goto(x-size*8.3, y-size*8.3)
    turtle.pendown()
    turtle.begin_fill()
    for i in range(4):
        turtle.forward(size*18)
        turtle.left(360 / 4)
    turtle.end_fill()
    turtle.penup()
    possqr()
def possqr():
    screen.onclick(square)
bsquare = Button(
    menu,
    text='square',
    width=10,
    command=possqr
).grid(column=4, row=10)

def pentagon(x, y):
    global la
    la.append('s')
    turtle.turtlesize(1,1)
    screen.onclick(None)
    turtle.ondrag(None)
    turtle.goto(x-size*6, y-size*9.5)
    turtle.pendown()    
    turtle.begin_fill()
    for i in range(5):
        turtle.forward(0.75*size*18)
        turtle.left(360 / 5)
    turtle.end_fill()
    turtle.penup()
    pospent()
def pospent():
    screen.onclick(pentagon)
bpentagon = Button(
    menu,
    text='pentagon',
    width=10,
    command=pospent
).grid(column=4, row=11)

def hexagon(x, y):
    global la
    la.append('s')
    turtle.turtlesize(1,1)
    screen.onclick(None)
    turtle.ondrag(None)
    turtle.goto(x-size*5.25, y-size*8.5)
    turtle.pendown()
    turtle.begin_fill()
    for i in range(6):
        turtle.forward(0.6*size*18)
        turtle.left(360 / 6)
    turtle.end_fill()
    turtle.penup()
    poshex()
def poshex():
    screen.onclick(hexagon)
bhexagon = Button(
    menu,
    text='hexagon',
    width=10,
    command=poshex
).grid(column=4, row=12)

def circlex(x, y):
    global la
    la.append('s')
    turtle.turtlesize(1,1)
    screen.onclick(None)
    turtle.ondrag(None)
    turtle.goto(x, y-size*9)
    turtle.pendown()
    turtle.begin_fill()
    turtle.circle(size*9)
    turtle.end_fill()
    turtle.penup()
    poscircle()
def poscircle():
    screen.onclick(circlex)
bcircle = Button(
    menu,
    text='circle',
    width=10,
    command=poscircle
).grid(column=4, row=13)

def heart(x, y):
    global la
    la.append('s')
    turtle.turtlesize(1,1)
    screen.onclick(None)
    turtle.ondrag(None)
    turtle.goto(x, y-size*12)
    turtle.pendown()
    turtle.begin_fill()
    # right side
    turtle.setheading(90)
    turtle.right(43.25)
    turtle.forward(size*20)
    # right curve
    turtle.setheading(90)
    turtle.right(17)
    turtle.circle(size*7,200)
    # left curve
    turtle.setheading(90)
    turtle.right(5)
    turtle.circle(size*7,200)
    # left side
    turtle.penup()
    turtle.goto(x,y-size*12)
    turtle.pendown()
    turtle.setheading(90)
    turtle.left(43.25)
    turtle.forward(size*20)
    #
    turtle.end_fill()
    turtle.penup()
    posheart()
def posheart():
    screen.onclick(heart)
bheart = Button(
    menu,
    text='heart',
    width=10,
    command=posheart
).grid(column=4, row=14)

def star(x, y):
    global la
    la.append('s')
    turtle.turtlesize(1,1)
    screen.onclick(None)
    turtle.ondrag(None)
    turtle.goto(x+size*4.6, y+size*6.5)
    turtle.pendown()
    turtle.begin_fill()
    turtle.setheading(90)
    turtle.left(23)
    for i in range (5) :
        turtle.forward(size*12)
        turtle.left(138)
        turtle.forward(size*12)
        turtle.right(66.8)
    turtle.setheading(90)
    turtle.end_fill()
    turtle.penup()
    posstar()
def posstar():
    screen.onclick(star)
bstar = Button(
    menu,
    text='star',
    width=10,
    command=posstar
).grid(column=4, row=15)

# extra buttons
Label(menu).grid(row=17, column=1)
Label(menu, text='actions', width=10).grid(column=1, row=18, columnspan=2, sticky=NE)
def undo ():
    if la[len(la)-1] =='s' : 
        turtle.undo()
        del(la[len(la)-1])
        while(turtle.isdown()==True) :
            turtle.undo()
        turtle.undo()
        turtle.undo()
    if la[len(la)-1]=='d' :
        turtle.undo()
        del(la[len(la)-1])
        while turtle.xcor()!=xp[len(xp)-1] and turtle.ycor()!=yp[len(yp)-1] :
            turtle.undo()
        del(xp[len(xp)-1])
        del(yp[len(yp)-1])
    screen.update()
    screen.getcanvas().update_idletasks()
bundo = Button(
    menu,
    text='undo',
    width=10,
    command=undo
).grid(column=1, row=19, columnspan=2, sticky=NE)
def clear () :
    turtle.clear()
    turtle.pensize(size)
    turtle.pencolor(cc)
    turtle.fillcolor(fc)
    la.append('b')
    turtle.penup()
bcls = Button(
    menu,
    text='erase',
    width=10,
    command=clear
).grid(column=1, row=20, columnspan=2, sticky=NE)
def save () :
    global name
    drawing = screen.getcanvas()
    drawing.postscript(file='drawing.ps')
    img = Image.open( 'drawing.ps')
    img.save('drawing'+str(name)+'.png')
    name=str(int(name)+1)
    with open ('name.txt','w') as f : 
        f.write(name)

bsave = Button(
    menu,
    text='save',
    width=10,
    command=save
).grid(column=1, row=21, columnspan=2, sticky=NE)

screen = TurtleScreen(canvas)
screen.tracer(False)
turtle = RawTurtle(screen)

main()

menu.mainloop()